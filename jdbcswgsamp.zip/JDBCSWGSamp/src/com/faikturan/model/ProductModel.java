package com.faikturan.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.faikturan.entities.Product;

public class ProductModel {
	public List<Product> findAll(){
		try {
			List<Product> listProducts = new ArrayList<>();
			PreparedStatement ps =
					ConnectDB.getConnection().
					prepareStatement("Select * from product order by name asc");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product p = new Product();
				p.setDescription(rs.getString("description"));
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getDouble("price"));
				p.setQuantity(rs.getInt("quantity"));
				listProducts.add(p);	
			}
			return listProducts;
		} catch (Exception e) {
			return null;
		}
	}
	
	public Product find(int id){
		try {
			Product p = new Product();
			PreparedStatement ps = 
					ConnectDB.getConnection().prepareStatement(
							"Select * from product where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p.setDescription(rs.getString("description"));
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getDouble("price"));
				p.setQuantity(rs.getInt("quantity"));
				
			}
			return p;
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
}

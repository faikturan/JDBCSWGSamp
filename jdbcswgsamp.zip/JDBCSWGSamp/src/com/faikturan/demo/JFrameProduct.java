package com.faikturan.demo;

import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import com.faikturan.entities.*;
import com.faikturan.model.*;

public class JFrameProduct{
	protected Shell shlProductManagement;
	private Table tableProduct;
	private Text textId;
	private Text textName;
	private Text textPrice;
	private Text textQuantity;
	private Text textDescription;
	
	private TableItem tableItem;
	private ProductModel pm = new ProductModel();
	
	public static void main(String[] args) {
	}

}
